<section id="hero" class="section-hero h-screen flex justify-center items-center bg-black text-white">
    <h1 class="text-5xl font-bold animate-text">Welcome to the Future of Bitcoin</h1>
</section>