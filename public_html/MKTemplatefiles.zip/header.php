<header>
    <nav>
        <ul>
            <li><a href="#hero">Hero</a></li>
            <li><a href="#bio">Bio</a></li>
            <li><a href="#obtener-btc">Obtener BTC</a></li>
            <li><a href="#choose-wallet">Choose Wallet</a></li>
            <li><a href="#recupera">Recupera</a></li>
            <li><a href="#blockchain">Blockchain</a></li>
            <li><a href="#coaching">Coaching</a></li>
        </ul>
    </nav>
</header>